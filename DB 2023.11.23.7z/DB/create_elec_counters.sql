-- Table: public.elec_counters

-- DROP TABLE IF EXISTS public.elec_counters;
-- counter_type: 	0 	-> 	منزلي
--					1	->	تجاري
--					2	->	محطة
--					3	->	مركز
CREATE TABLE IF NOT EXISTS public.elec_counters
(
    id bigserial,
    osm_id bigint,
    center_id bigint,
    user_id bigint,
    mean_consumption double precision DEFAULT 0,
    last_consumption double precision DEFAULT 0,
    counter_type integer DEFAULT 0,
    last_invoice double precision DEFAULT 0,
    invoice_was_paid boolean DEFAULT false,
    CONSTRAINT elec_counters_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.elec_counters
    OWNER to postgres;