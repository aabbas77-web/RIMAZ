-- Table: public.elec_users

-- DROP TABLE IF EXISTS public.elec_users;

CREATE TABLE IF NOT EXISTS public.elec_users
(
    id bigserial,
    first_name text COLLATE pg_catalog."default",
    last_name text COLLATE pg_catalog."default",
    tele text COLLATE pg_catalog."default" UNIQUE,
    mobile_number text COLLATE pg_catalog."default" UNIQUE,
    email text COLLATE pg_catalog."default" UNIQUE,
    address text COLLATE pg_catalog."default",
    CONSTRAINT elec_users_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.elec_users
    OWNER to postgres;