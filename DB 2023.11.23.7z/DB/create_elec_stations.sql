-- Table: public.elec_stations

-- DROP TABLE IF EXISTS public.elec_stations;

CREATE TABLE IF NOT EXISTS public.elec_stations
(
    id bigserial,
    name text COLLATE pg_catalog."default" UNIQUE,
    consumption double precision DEFAULT 0,
    date date,
    CONSTRAINT elec_stations_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.elec_stations
    OWNER to postgres;