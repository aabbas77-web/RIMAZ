create or replace function get_power_lines_length_km(ewkt_geom text)
returns double precision
language plpgsql
as
$$
declare
   length_km double precision;
begin
	select sum(ST_Length2D(way))
	into length_km
	from planet_osm_line
	where ("power" like '%line%') and st_intersects(way, ST_GeomFromEWKT(ewkt_geom));
	
	return round(length_km)/1000;
end;
$$;
