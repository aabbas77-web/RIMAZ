-- Table: public.elec_centers

-- DROP TABLE IF EXISTS public.elec_centers;

CREATE TABLE IF NOT EXISTS public.elec_centers
(
    id bigserial,
    station_id bigint,
    name text COLLATE pg_catalog."default" UNIQUE,
    consumption double precision DEFAULT 0,
    date date,
    CONSTRAINT elec_centers_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.elec_centers
    OWNER to postgres;