create or replace function get_center_counters_count(center__id bigint)
returns bigint
language plpgsql
as
$$
declare
   countersCount bigint;
begin
	select count(*)
	into countersCount
	from elec_counters
	where center_id = center__id;
   
	return countersCount;
end;
$$;
