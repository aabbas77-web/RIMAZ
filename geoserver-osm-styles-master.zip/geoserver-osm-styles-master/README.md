geoserver-osm-styles
====================

sld files used by rogue project that fixes many issues after converting the OpenStreetMap mapnik styles to slds. This folder contains sub-folders holding layers, SLDs, symbols, and schema used for several OSM-specific layers. Many of these layers were imported from OSM and used during the TD1 and TD2 exercises. (TD1 - Feb 2013, TD2 - Jul 2013).
