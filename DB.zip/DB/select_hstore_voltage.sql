SELECT * FROM public.planet_osm_line
WHERE (power is not null) AND (tags->'voltage' is not null)
