create or replace function get_station_consumption(station__id bigint)
returns double precision
language plpgsql
as
$$
declare
   consumption double precision;
begin
	SELECT sum(last_consumption)
	into consumption
	FROM (select * from elec_centers where station_id = station__id) M
	INNER JOIN elec_counters D
		ON M.id = D.center_id;
   
	return consumption;
end;
$$;
