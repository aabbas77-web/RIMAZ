create or replace function get_station_counters_count(station__id bigint)
returns bigint
language plpgsql
as
$$
declare
   countersCount bigint;
begin
	SELECT count(*)
	into countersCount
	FROM (select * from elec_centers where station_id = station__id) M
	INNER JOIN elec_counters D
		ON M.id = D.center_id;
   
	return countersCount;
end;
$$;
