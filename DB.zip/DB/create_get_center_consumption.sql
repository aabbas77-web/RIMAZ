create or replace function get_center_consumption(center__id bigint)
returns double precision
language plpgsql
as
$$
declare
   consumption double precision;
begin
	select sum(last_consumption)
	into consumption
	from elec_counters
	where center_id = center__id;

	return consumption;
end;
$$;
